# R Statistics Essential Training
# Ex06_02
# Creating grouped boxplots
