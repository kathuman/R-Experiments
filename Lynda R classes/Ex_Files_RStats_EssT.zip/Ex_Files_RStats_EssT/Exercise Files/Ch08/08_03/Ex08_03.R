# R Statistics Essential Training
# Ex08_03
# Creating scatterplot matrices

