# R Statistics Essential Training
# Ex07_05
# Comparing means with ANOVA
