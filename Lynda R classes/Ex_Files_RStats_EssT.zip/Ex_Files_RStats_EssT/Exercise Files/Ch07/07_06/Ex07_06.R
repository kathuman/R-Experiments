# R Statistics Essential Training
# Ex07_06
# Comparing proportions
