# R Statistics Essential Training
# Ex07_02
# Computing a bivariate regression
