# R Statistics Essential Training
# Ex07_03
# Comparing means with the t-test
