# R Statistics Essential Training
# Ex05_03
# Merging files

