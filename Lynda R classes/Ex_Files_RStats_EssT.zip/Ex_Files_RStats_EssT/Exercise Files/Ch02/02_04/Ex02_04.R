# R Statistics Essential Training
# Ex02_04
# Creating boxplots for quantitative variables
