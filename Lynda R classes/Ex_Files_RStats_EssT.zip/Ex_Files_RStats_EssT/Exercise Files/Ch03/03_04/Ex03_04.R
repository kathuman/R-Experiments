# R Statistics Essential Training
# Ex03_04
# Single mean: Hypothesis test and confidence interval
