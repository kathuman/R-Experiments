# R Statistics Essential Training
# Ex03_01
# Calculating frequencies
