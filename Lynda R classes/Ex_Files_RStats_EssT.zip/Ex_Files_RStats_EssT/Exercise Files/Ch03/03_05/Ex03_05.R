# R Statistics Essential Training
# Ex03_05
# Single categorical variable: One sample chi-square test
