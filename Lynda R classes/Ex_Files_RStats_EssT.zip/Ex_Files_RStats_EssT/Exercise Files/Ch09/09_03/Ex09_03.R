# R Statistics Essential Training
# Ex09_03
# Conducting a cluster analysis

