# R Statistics Essential Training
# Ex09_01
# Computing a multiple regression

