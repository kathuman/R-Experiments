# R Statistics Essential Training
# Ex09_02
# Comparing means with a two-factor ANOVA

