# R Statistics Essential Training
# Ex09_04
# Conducting a principal components/factor analysis

