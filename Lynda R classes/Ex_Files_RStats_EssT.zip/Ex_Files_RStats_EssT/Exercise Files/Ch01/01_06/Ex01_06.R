# R Statistics Essential Training
# Ex01_06
# Entering data manually
