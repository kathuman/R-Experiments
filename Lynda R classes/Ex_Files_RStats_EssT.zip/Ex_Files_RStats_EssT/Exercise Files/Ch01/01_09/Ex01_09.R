# R Statistics Essential Training
# Ex01_09
# Working with color
