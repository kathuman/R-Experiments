# R Statistics Essential Training
# Ex01_03
# Taking a first look at the interface