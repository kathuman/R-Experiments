# R Statistics Essential Training
# Ex04_03
# Computing composite variables
