# R Statistics Essential Training
# Ex04_04
# Coding missing data
